# SHUU - Modern Shoe Store

A Gen Z-focused e-commerce website for sneakers and footwear, featuring a dark theme with glass morphism effects.

## 🚀 Features

- **Dark Mode First Design** - Modern aesthetic with optional light mode
- **Glass Morphism UI** - Beautiful glass effects throughout
- **Responsive Design** - Mobile-first approach
- **E-commerce Functionality** - Full shopping experience
- **Modern Animations** - Smooth transitions and interactions
- **Performance Optimized** - Fast loading and smooth interactions

## 📁 Project Structure
