// Authentication and account functionality for SHUU website

class UserAuth {
    constructor() {
        this.currentUser = JSON.parse(localStorage.getItem('shuu-current-user')) || null;
        this.users = JSON.parse(localStorage.getItem('shuu-users')) || [];
        this.init();
    }
    
    init() {
        this.updateUserDisplay();
        this.attachAuthEventListeners();
        this.initializeAccountSections();
    }
    
    attachAuthEventListeners() {
        // Login form
        const loginForm = document.getElementById('login-form');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        }
        
        // Registration form
        const registerForm = document.getElementById('register-form');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => this.handleRegister(e));
        }
        
        // Settings form
        const settingsForm = document.querySelector('.settings-form');
        if (settingsForm) {
            settingsForm.addEventListener('submit', (e) => this.handleSettingsUpdate(e));
        }
        
        // Logout
        const logoutBtn = document.querySelector('.account-nav-link[href="#logout"]');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleLogout();
            });
        }
    }
    
    handleLogin(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const email = formData.get('email');
        const password = formData.get('password');
        
        const user = this.users.find(u => u.email === email && u.password === password);
        
        if (user) {
            this.currentUser = user;
            localStorage.setItem('shuu-current-user', JSON.stringify(user));
            this.updateUserDisplay();
            showNotification('Welcome back!', 'success');
            
            // Redirect to account page
            setTimeout(() => {
                window.location.href = 'account.html';
            }, 1000);
        } else {
            showNotification('Invalid email or password', 'error');
        }
    }
    
    handleRegister(e) {
        e.preventDefault();
        const formData = new FormData(e.target);
        const userData = {
            id: Date.now(),
            firstName: formData.get('firstName'),
            lastName: formData.get('lastName'),
            email: formData.get('email'),
            password: formData.get('password'),
            phone: formData.get('phone'),
            joinDate: new Date().toISOString(),
            orders: [],
            addresses: [],
            wishlist: []
        };
        
        // Check if user already exists
        if (this.users.find(u => u.email === userData.email)) {
            showNotification('User with this email already exists', 'error');
            return;
        }
        
        this.users.push(userData);
        this.currentUser = userData;
        
        localStorage.setItem('shuu-users', JSON.stringify(this.users));
        localStorage.setItem('shuu-current-user', JSON.stringify(userData));
        
        this.updateUserDisplay();
        showNotification('Account created successfully!', 'success');
        
        // Redirect to account page
        setTimeout(() => {
            window.location.href = 'account.html';
        }, 1000);
    }
    
    handleSettingsUpdate(e) {
        e.preventDefault();
        
        if (!this.currentUser) {
            showNotification('Please log in to update your settings', 'error');
            return;
        }
        
        const formData = new FormData(e.target);
        const updatedUser = {
            ...this.currentUser,
            firstName: formData.get('firstName') || this.currentUser.firstName,
            lastName: formData.get('lastName') || this.currentUser.lastName,
            email: formData.get('email') || this.currentUser.email,
            phone: formData.get('phone') || this.currentUser.phone
        };
        
        // Update password if provided
        const newPassword = formData.get('password');
        if (newPassword) {
            updatedUser.password = newPassword;
        }
        
        // Update in users array
        const userIndex = this.users.findIndex(u => u.id === this.currentUser.id);
        if (userIndex > -1) {
            this.users[userIndex] = updatedUser;
        }
        
        this.currentUser = updatedUser;
        
        localStorage.setItem('shuu-users', JSON.stringify(this.users));
        localStorage.setItem('shuu-current-user', JSON.stringify(updatedUser));
        
        showNotification('Settings updated successfully!', 'success');
    }
    
    handleLogout() {
        this.currentUser = null;
        localStorage.removeItem('shuu-current-user');
        this.updateUserDisplay();
        showNotification('Logged out successfully', 'success');
        
        // Redirect to home page
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
    }
    
    updateUserDisplay() {
        const accountLinks = document.querySelectorAll('.account-icon, .account-nav-link');
        const userNameElements = document.querySelectorAll('.user-name, .account-section h2');
        
        if (this.currentUser) {
            // User is logged in
            accountLinks.forEach(link => {
                link.style.display = 'flex';
            });
            
            userNameElements.forEach(element => {
                if (element.classList.contains('user-name')) {
                    element.textContent = `${this.currentUser.firstName} ${this.currentUser.lastName}`;
                } else if (element.textContent.includes('Welcome')) {
                    element.textContent = `Welcome Back, ${this.currentUser.firstName}!`;
                }
            });
            
            // Populate settings form
            this.populateSettingsForm();
            
        } else {
            // User is not logged in
            accountLinks.forEach(link => {
                if (link.classList.contains('account-nav-link') && !link.href.includes('account.html')) {
                    link.style.display = 'none';
                }
            });
            
            // Redirect to login if on account page
            if (window.location.pathname.includes('account.html')) {
                window.location.href = 'login.html';
            }
        }
    }
    
    populateSettingsForm() {
        if (!this.currentUser) return;
        
        const form = document.querySelector('.settings-form');
        if (!form) return;
        
        const fields = {
            'firstName': this.currentUser.firstName,
            'lastName': this.currentUser.lastName,
            'email': this.currentUser.email,
            'phone': this.currentUser.phone || ''
        };
        
        Object.entries(fields).forEach(([name, value]) => {
            const field = form.querySelector(`[name="${name}"]`);
            if (field) {
                field.value = value;
            }
        });
    }
    
    initializeAccountSections() {
        // Initialize addresses
        this.initializeAddresses();
        
        // Initialize orders
        this.initializeOrders();
        
        // Initialize wishlist
        this.initializeWishlist();
    }
    
    initializeAddresses() {
        const addressesGrid = document.querySelector('.addresses-grid');
        if (!addressesGrid) return;
        
        if (this.currentUser && this.currentUser.addresses && this.currentUser.addresses.length > 0) {
            // Display user addresses
            addressesGrid.innerHTML = this.currentUser.addresses.map(address => `
                <div class="address-card">
                    <div class="address-header">
                        <h4>${address.type}</h4>
                        ${address.isDefault ? '<span class="default-badge">Default</span>' : ''}
                    </div>
                    <div class="address-details">
                        <p>${address.firstName} ${address.lastName}</p>
                        <p>${address.street}</p>
                        <p>${address.city}, ${address.postcode}</p>
                        <p>${address.country}</p>
                        <p>${address.phone}</p>
                    </div>
                    <div class="address-actions">
                        <button class="btn-text" onclick="userAuth.editAddress(${address.id})">Edit</button>
                        <button class="btn-text" onclick="userAuth.deleteAddress(${address.id})">Delete</button>
                    </div>
                </div>
            `).join('') + `
                <div class="address-card add-new" onclick="userAuth.showAddressForm()">
                    <div class="add-address">
                        <i class="fas fa-plus"></i>
                        <h4>Add New Address</h4>
                    </div>
                </div>
            `;
        } else {
            // Show empty state with add button
            addressesGrid.innerHTML = `
                <div class="address-card add-new" onclick="userAuth.showAddressForm()">
                    <div class="add-address">
                        <i class="fas fa-plus"></i>
                        <h4>Add Your First Address</h4>
                        <p>Click here to add a shipping address</p>
                    </div>
                </div>
            `;
        }
    }
    
    initializeOrders() {
        const ordersList = document.querySelector('.orders-list');
        if (!ordersList) return;
        
        if (this.currentUser && this.currentUser.orders && this.currentUser.orders.length > 0) {
            ordersList.innerHTML = this.currentUser.orders.map(order => `
                <div class="order-card">
                    <div class="order-header">
                        <div class="order-meta">
                            <h4>Order #${order.id}</h4>
                            <p>Placed on ${new Date(order.date).toLocaleDateString()}</p>
                        </div>
                        <div class="order-status ${order.status}">${order.status}</div>
                    </div>
                    <div class="order-items">
                        ${order.items.map(item => `
                            <div class="order-item-preview">
                                <img src="${item.image}" alt="${item.name}">
                                <div class="item-details">
                                    <h5>${item.name}</h5>
                                    <p>Size: ${item.size} | Qty: ${item.quantity}</p>
                                </div>
                                <div class="item-price">${formatPrice(item.price)}</div>
                            </div>
                        `).join('')}
                    </div>
                    <div class="order-footer">
                        <div class="order-total">Total: ${formatPrice(order.total)}</div>
                        <button class="btn btn-outline">View Details</button>
                    </div>
                </div>
            `).join('');
        } else {
            ordersList.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-shopping-bag"></i>
                    <h3>No Orders Yet</h3>
                    <p>Your order history will appear here</p>
                    <a href="products.html" class="btn">Start Shopping</a>
                </div>
            `;
        }
    }
    
    initializeWishlist() {
        const wishlistGrid = document.querySelector('#wishlist .products-grid');
        if (!wishlistGrid) return;
        
        if (this.currentUser && this.currentUser.wishlist && this.currentUser.wishlist.length > 0) {
            wishlistGrid.innerHTML = this.currentUser.wishlist.map(item => `
                <div class="product-card">
                    <button class="wishlist-remove" onclick="userAuth.removeFromWishlist(${item.id})">
                        <i class="fas fa-times"></i>
                    </button>
                    <div class="product-image">
                        <img src="${item.image}" alt="${item.name}">
                    </div>
                    <div class="product-info">
                        <h3 class="product-title">${item.name}</h3>
                        <div class="product-price">
                            <span class="current-price">${formatPrice(item.price)}</span>
                        </div>
                        <button class="add-to-cart" onclick="addToCart(${JSON.stringify(item).replace(/"/g, '&quot;')})">
                            ADD TO BAG
                        </button>
                    </div>
                </div>
            `).join('');
        } else {
            wishlistGrid.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-heart"></i>
                    <h3>Your Wishlist is Empty</h3>
                    <p>Save items you love for later</p>
                    <a href="products.html" class="btn">Explore Products</a>
                </div>
            `;
        }
    }
    
    showAddressForm() {
        // Implementation for address form modal
        showNotification('Address form feature coming soon!', 'success');
    }
    
    editAddress(addressId) {
        showNotification('Edit address feature coming soon!', 'success');
    }
    
    deleteAddress(addressId) {
        if (confirm('Are you sure you want to delete this address?')) {
            this.currentUser.addresses = this.currentUser.addresses.filter(addr => addr.id !== addressId);
            this.saveUserData();
            this.initializeAddresses();
            showNotification('Address deleted successfully', 'success');
        }
    }
    
    removeFromWishlist(itemId) {
        this.currentUser.wishlist = this.currentUser.wishlist.filter(item => item.id !== itemId);
        this.saveUserData();
        this.initializeWishlist();
        showNotification('Item removed from wishlist', 'success');
    }
    
    saveUserData() {
        const userIndex = this.users.findIndex(u => u.id === this.currentUser.id);
        if (userIndex > -1) {
            this.users[userIndex] = this.currentUser;
        }
        
        localStorage.setItem('shuu-users', JSON.stringify(this.users));
        localStorage.setItem('shuu-current-user', JSON.stringify(this.currentUser));
    }
    
    isLoggedIn() {
        return this.currentUser !== null;
    }
    
    getCurrentUser() {
        return this.currentUser;
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.userAuth = new UserAuth();
    
    // Add styles for empty states
    if (!document.querySelector('#auth-styles')) {
        const styles = document.createElement('style');
        styles.id = 'auth-styles';
        styles.textContent = `
            .empty-state {
                text-align: center;
                padding: 60px 20px;
                color: var(--text-secondary);
            }
            .empty-state i {
                font-size: 3rem;
                margin-bottom: 20px;
                opacity: 0.5;
            }
            .empty-state h3 {
                margin-bottom: 10px;
                color: var(--text-primary);
            }
            .empty-state p {
                margin-bottom: 25px;
            }
            .login-form,
            .register-form {
                max-width: 400px;
                margin: 0 auto;
            }
            .form-options {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
            }
            .remember-me {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .forgot-password {
                color: var(--accent);
                text-decoration: none;
            }
            .auth-divider {
                text-align: center;
                margin: 30px 0;
                position: relative;
                color: var(--text-secondary);
            }
            .auth-divider::before {
                content: '';
                position: absolute;
                top: 50%;
                left: 0;
                right: 0;
                height: 1px;
                background: var(--glass-border);
            }
            .auth-divider span {
                background: var(--card-bg);
                padding: 0 15px;
                position: relative;
            }
            .social-auth {
                display: flex;
                gap: 15px;
                margin-bottom: 25px;
            }
            .social-auth-btn {
                flex: 1;
                padding: 12px;
                border: 1px solid var(--glass-border);
                border-radius: 8px;
                background: rgba(255, 255, 255, 0.05);
                color: var(--text-primary);
                cursor: pointer;
                transition: all 0.3s;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
            }
            .social-auth-btn:hover {
                border-color: var(--accent);
                background: rgba(255, 51, 102, 0.1);
            }
            .auth-switch {
                text-align: center;
                margin-top: 25px;
                color: var(--text-secondary);
            }
            .auth-switch a {
                color: var(--accent);
                text-decoration: none;
                font-weight: 600;
            }
        `;
        document.head.appendChild(styles);
    }
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        UserAuth
    };
}