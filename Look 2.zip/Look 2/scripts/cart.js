// Cart functionality for SHUU website

class ShoppingCart {
    constructor() {
        this.cart = JSON.parse(localStorage.getItem('shuu-cart')) || [];
        this.init();
    }
    
    init() {
        this.updateCartDisplay();
        this.attachEventListeners();
    }
    
    attachEventListeners() {
        // Quantity controls
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('quantity-btn')) {
                this.handleQuantityChange(e);
            }
            
            if (e.target.classList.contains('remove-item') || e.target.closest('.remove-item')) {
                this.handleRemoveItem(e);
            }
        });
        
        // Checkout button
        const checkoutBtn = document.querySelector('.checkout-btn-full');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', (e) => {
                if (this.cart.length === 0) {
                    e.preventDefault();
                    showNotification('Your cart is empty!', 'error');
                }
            });
        }
    }
    
    handleQuantityChange(e) {
        const button = e.target.classList.contains('quantity-btn') ? e.target : e.target.closest('.quantity-btn');
        const bagItem = button.closest('.bag-item');
        const itemName = bagItem.querySelector('.bag-item-title').textContent;
        const quantityElement = bagItem.querySelector('.quantity');
        let quantity = parseInt(quantityElement.textContent);
        
        if (button.classList.contains('plus')) {
            quantity++;
        } else if (button.classList.contains('minus') && quantity > 1) {
            quantity--;
        }
        
        quantityElement.textContent = quantity;
        this.updateItemQuantity(itemName, quantity);
        this.updateCartDisplay();
    }
    
    handleRemoveItem(e) {
        const button = e.target.classList.contains('remove-item') ? e.target : e.target.closest('.remove-item');
        const bagItem = button.closest('.bag-item');
        const itemName = bagItem.querySelector('.bag-item-title').textContent;
        
        this.removeItem(itemName);
        bagItem.style.opacity = '0';
        bagItem.style.transform = 'translateX(100px)';
        
        setTimeout(() => {
            bagItem.remove();
            this.updateCartDisplay();
        }, 300);
    }
    
    updateItemQuantity(itemName, quantity) {
        const itemIndex = this.cart.findIndex(item => item.name === itemName);
        if (itemIndex > -1) {
            this.cart[itemIndex].quantity = quantity;
            this.saveCart();
        }
    }
    
    removeItem(itemName) {
        this.cart = this.cart.filter(item => item.name !== itemName);
        this.saveCart();
        showNotification('Item removed from cart', 'success');
    }
    
    updateCartDisplay() {
        this.updateCartItems();
        this.updateCartSummary();
        this.updateCartCount();
    }
    
    updateCartItems() {
        const cartItemsContainer = document.querySelector('.cart-items');
        const bagItemsContainer = document.querySelector('.bag-items');
        
        if (this.cart.length === 0) {
            // Show empty state
            if (cartItemsContainer) {
                cartItemsContainer.innerHTML = `
                    <div class="cart-empty">
                        <i class="fas fa-shopping-bag"></i>
                        <p>YOUR CART IS EMPTY</p>
                        <p style="margin-top: 10px; font-size: 0.9rem;">Add some fresh kicks!</p>
                    </div>
                `;
            }
            
            if (bagItemsContainer) {
                bagItemsContainer.innerHTML = `
                    <div class="cart-empty">
                        <i class="fas fa-shopping-bag"></i>
                        <p>YOUR BAG IS EMPTY</p>
                        <p style="margin-top: 10px; font-size: 0.9rem;">Add some fresh kicks!</p>
                    </div>
                `;
            }
            
            return;
        }
        
        // Update cart sidebar
        if (cartItemsContainer) {
            cartItemsContainer.innerHTML = this.cart.map(item => `
                <div class="cart-item">
                    <div class="cart-item-image">
                        <img src="${item.image}" alt="${item.name}">
                    </div>
                    <div class="cart-item-details">
                        <h4>${item.name}</h4>
                        <div class="cart-item-price">${item.price}</div>
                        <div class="cart-item-quantity">Qty: ${item.quantity}</div>
                    </div>
                </div>
            `).join('');
        }
        
        // Update bag page
        if (bagItemsContainer) {
            bagItemsContainer.innerHTML = this.cart.map(item => `
                <div class="bag-item">
                    <div class="bag-item-image">
                        <img src="${item.image}" alt="${item.name}">
                    </div>
                    <div class="bag-item-details">
                        <h3 class="bag-item-title">${item.name}</h3>
                        <div class="bag-item-price">${item.price}</div>
                        <div class="bag-item-meta">
                            <span>Size: UK 9</span>
                            <span>Color: Black</span>
                        </div>
                        <div class="quantity-controls">
                            <button class="quantity-btn minus">-</button>
                            <span class="quantity">${item.quantity}</span>
                            <button class="quantity-btn plus">+</button>
                        </div>
                    </div>
                    <button class="remove-item">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `).join('');
        }
    }
    
    updateCartSummary() {
        const subtotal = this.calculateSubtotal();
        const tax = this.calculateTax(subtotal);
        const total = subtotal + tax;
        
        // Update cart sidebar
        const cartTotal = document.querySelector('.cart-total span:last-child');
        if (cartTotal) {
            cartTotal.textContent = formatPrice(total);
        }
        
        // Update bag page summary
        const summaryRows = document.querySelectorAll('.summary-row');
        if (summaryRows.length > 0) {
            const subtotalElement = summaryRows[0].querySelector('span:last-child');
            const taxElement = summaryRows[2].querySelector('span:last-child');
            const totalElement = document.querySelector('.summary-total span:last-child');
            
            if (subtotalElement) subtotalElement.textContent = formatPrice(subtotal);
            if (taxElement) taxElement.textContent = formatPrice(tax);
            if (totalElement) totalElement.textContent = formatPrice(total);
        }
        
        // Update checkout page
        const checkoutSubtotal = document.querySelector('.summary-details .summary-row:first-child span:last-child');
        const checkoutTax = document.querySelector('.summary-details .summary-row:nth-child(3) span:last-child');
        const checkoutTotal = document.querySelector('.summary-details .total span:last-child');
        
        if (checkoutSubtotal) checkoutSubtotal.textContent = formatPrice(subtotal);
        if (checkoutTax) checkoutTax.textContent = formatPrice(tax);
        if (checkoutTotal) checkoutTotal.textContent = formatPrice(total);
    }
    
    calculateSubtotal() {
        return this.cart.reduce((total, item) => {
            const price = parseFloat(item.price.replace(/[^0-9.]/g, ''));
            return total + (price * item.quantity);
        }, 0);
    }
    
    calculateTax(subtotal) {
        return subtotal * 0.2; // 20% VAT
    }
    
    updateCartCount() {
        const totalItems = this.cart.reduce((total, item) => total + item.quantity, 0);
        const cartCount = document.querySelector('.cart-count');
        
        if (cartCount) {
            if (totalItems > 0) {
                cartCount.textContent = totalItems;
                cartCount.style.display = 'flex';
            } else {
                cartCount.style.display = 'none';
            }
        }
    }
    
    saveCart() {
        localStorage.setItem('shuu-cart', JSON.stringify(this.cart));
    }
    
    clearCart() {
        this.cart = [];
        this.saveCart();
        this.updateCartDisplay();
    }
    
    getCart() {
        return this.cart;
    }
}

// Checkout form handling
function initializeCheckout() {
    const checkoutForm = document.getElementById('contactForm') || document.querySelector('.checkout-form form');
    
    if (checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Validate form
            if (validateCheckoutForm(this)) {
                // Simulate payment processing
                const submitBtn = this.querySelector('button[type="submit"]');
                const originalText = submitBtn.textContent;
                
                submitBtn.textContent = 'PROCESSING...';
                submitBtn.disabled = true;
                
                setTimeout(() => {
                    // Show success message
                    showNotification('Order placed successfully!', 'success');
                    
                    // Clear cart
                    if (window.shoppingCart) {
                        window.shoppingCart.clearCart();
                    }
                    
                    // Redirect to confirmation page (in a real app)
                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 2000);
                    
                }, 2000);
            }
        });
    }
    
    // Payment method selection
    const paymentMethods = document.querySelectorAll('.payment-method');
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            paymentMethods.forEach(m => m.classList.remove('active'));
            this.classList.add('active');
            
            // Show/hide card details based on selection
            const cardDetails = document.querySelector('.card-details');
            if (cardDetails) {
                if (this.querySelector('span').textContent === 'Card') {
                    cardDetails.style.display = 'block';
                } else {
                    cardDetails.style.display = 'none';
                }
            }
        });
    });
    
    // Shipping option selection
    const shippingOptions = document.querySelectorAll('.shipping-option');
    shippingOptions.forEach(option => {
        option.addEventListener('click', function() {
            shippingOptions.forEach(o => o.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

function validateCheckoutForm(form) {
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!field.value.trim()) {
            field.style.borderColor = 'var(--error)';
            isValid = false;
        } else {
            field.style.borderColor = '';
        }
    });
    
    // Validate email
    const emailField = form.querySelector('input[type="email"]');
    if (emailField && emailField.value) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(emailField.value)) {
            emailField.style.borderColor = 'var(--error)';
            isValid = false;
            showNotification('Please enter a valid email address', 'error');
        }
    }
    
    if (!isValid) {
        showNotification('Please fill in all required fields', 'error');
    }
    
    return isValid;
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize shopping cart
    window.shoppingCart = new ShoppingCart();
    
    // Initialize checkout functionality
    if (document.querySelector('.checkout-form') || document.getElementById('contactForm')) {
        initializeCheckout();
    }
    
    // Add styles for cart items
    if (!document.querySelector('#cart-styles')) {
        const styles = document.createElement('style');
        styles.id = 'cart-styles';
        styles.textContent = `
            .cart-item {
                display: flex;
                gap: 15px;
                padding: 15px 0;
                border-bottom: 1px solid var(--glass-border);
            }
            .cart-item:last-child {
                border-bottom: none;
            }
            .cart-item-image {
                width: 60px;
                height: 60px;
                background: var(--gray-light);
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
            }
            .cart-item-image img {
                width: 80%;
                height: 80%;
                object-fit: contain;
            }
            .cart-item-details {
                flex: 1;
            }
            .cart-item-details h4 {
                font-size: 0.9rem;
                margin-bottom: 5px;
                color: var(--text-primary);
            }
            .cart-item-price {
                color: var(--accent);
                font-weight: 600;
                margin-bottom: 5px;
                font-size: 0.9rem;
            }
            .cart-item-quantity {
                color: var(--text-secondary);
                font-size: 0.8rem;
            }
        `;
        document.head.appendChild(styles);
    }
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        ShoppingCart,
        initializeCheckout,
        validateCheckoutForm
    };
}