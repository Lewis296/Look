// Product Details Page Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Image Thumbnail Selection
    const thumbnails = document.querySelectorAll('.thumbnail');
    const mainImage = document.getElementById('main-product-image');
    
    thumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', function() {
            // Remove active class from all thumbnails
            thumbnails.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked thumbnail
            this.classList.add('active');
            
            // Update main image
            const newImageSrc = this.getAttribute('data-image');
            mainImage.src = newImageSrc;
        });
    });
    
    // Size Selection
    const sizeOptions = document.querySelectorAll('.size-option');
    let selectedSize = null;
    
    sizeOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove selected class from all options
            sizeOptions.forEach(o => o.classList.remove('selected'));
            
            // Add selected class to clicked option
            this.classList.add('selected');
            selectedSize = this.textContent.trim();
            
            // Enable add to cart button
            updateAddToCartButton();
        });
    });
    
    // Tab Functionality
    const tabHeaders = document.querySelectorAll('.tab-header');
    const tabPanes = document.querySelectorAll('.tab-pane');
    
    tabHeaders.forEach(header => {
        header.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Remove active class from all headers and panes
            tabHeaders.forEach(h => h.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));
            
            // Add active class to clicked header and corresponding pane
            this.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        });
    });
    
    // Add to Cart Functionality
    const addToCartBtn = document.getElementById('add-to-cart');
    
    function updateAddToCartButton() {
        if (selectedSize) {
            addToCartBtn.disabled = false;
            addToCartBtn.textContent = `ADD TO BAG - UK ${selectedSize.split(' ')[1]}`;
        } else {
            addToCartBtn.disabled = true;
            addToCartBtn.innerHTML = '<i class="fas fa-shopping-bag"></i> SELECT SIZE';
        }
    }
    
    addToCartBtn.addEventListener('click', function() {
        if (!selectedSize) {
            alert('Please select a size before adding to cart.');
            return;
        }
        
        // Add to cart logic here
        const product = {
            name: 'Nike Air Max 97 Silver Bullet',
            price: 170.00,
            size: selectedSize,
            image: 'assets/images/products/shoe1-thumb1.jpg'
        };
        
        addToCart(product);
        showAddToCartNotification();
    });
    
    function addToCart(product) {
        // Get existing cart from localStorage or initialize empty array
        let cart = JSON.parse(localStorage.getItem('shuu_cart')) || [];
        
        // Add new product to cart
        cart.push(product);
        
        // Save back to localStorage
        localStorage.setItem('shuu_cart', JSON.stringify(cart));
        
        // Update cart count
        updateCartCount();
    }
    
    function updateCartCount() {
        const cart = JSON.parse(localStorage.getItem('shuu_cart')) || [];
        const cartCount = document.querySelector('.cart-count');
        cartCount.textContent = cart.length;
    }
    
    function showAddToCartNotification() {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'add-to-cart-notification';
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-check-circle"></i>
                <span>Added to bag successfully!</span>
                <a href="bag.html" class="view-bag-btn">View Bag</a>
            </div>
        `;
        
        // Add styles
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: var(--success);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            z-index: 1000;
            animation: slideInRight 0.3s ease;
        `;
        
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
    
    // Wishlist Functionality
    const wishlistBtn = document.querySelector('.wishlist-btn');
    
    wishlistBtn.addEventListener('click', function() {
        const product = {
            name: 'Nike Air Max 97 Silver Bullet',
            price: 170.00,
            image: 'assets/images/products/shoe1-thumb1.jpg'
        };
        
        addToWishlist(product);
        toggleWishlistButton();
    });
    
    function addToWishlist(product) {
        let wishlist = JSON.parse(localStorage.getItem('shuu_wishlist')) || [];
        wishlist.push(product);
        localStorage.setItem('shuu_wishlist', JSON.stringify(wishlist));
    }
    
    function toggleWishlistButton() {
        const icon = wishlistBtn.querySelector('i');
        if (icon.classList.contains('far')) {
            icon.className = 'fas fa-heart';
            wishlistBtn.style.color = 'var(--accent)';
        } else {
            icon.className = 'far fa-heart';
            wishlistBtn.style.color = '';
        }
    }
    
    // Initialize cart count
    updateCartCount();
    
    // Initialize add to cart button state
    updateAddToCartButton();
});

// CSS for notifications (could be moved to main CSS)
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    .add-to-cart-notification .notification-content {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    
    .view-bag-btn {
        color: white;
        text-decoration: underline;
        font-weight: 500;
        margin-left: 0.5rem;
    }
    
    .view-bag-btn:hover {
        color: rgba(255,255,255,0.8);
    }
`;
document.head.appendChild(style);
