// Utility functions for SHUU website

// Format price to GBP
function formatPrice(price) {
    return new Intl.NumberFormat('en-GB', {
        style: 'currency',
        currency: 'GBP',
        minimumFractionDigits: 2
    }).format(price);
}

// Debounce function for performance
function debounce(func, wait, immediate) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            timeout = null;
            if (!immediate) func(...args);
        };
        const callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func(...args);
    };
}

// Throttle function for performance
function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// Local storage utilities
const Storage = {
    set: (key, value) => {
        try {
            localStorage.setItem(`shuu-${key}`, JSON.stringify(value));
            return true;
        } catch (error) {
            console.error('Storage set error:', error);
            return false;
        }
    },

    get: (key) => {
        try {
            const item = localStorage.getItem(`shuu-${key}`);
            return item ? JSON.parse(item) : null;
        } catch (error) {
            console.error('Storage get error:', error);
            return null;
        }
    },

    remove: (key) => {
        try {
            localStorage.removeItem(`shuu-${key}`);
            return true;
        } catch (error) {
            console.error('Storage remove error:', error);
            return false;
        }
    },

    clear: () => {
        try {
            localStorage.clear();
            return true;
        } catch (error) {
            console.error('Storage clear error:', error);
            return false;
        }
    }
};

// Form validation utilities
const Validators = {
    email: (email) => {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    },

    phone: (phone) => {
        const regex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
        return regex.test(phone.replace(/\s/g, ''));
    },

    password: (password) => {
        return password.length >= 8;
    },

    postcode: (postcode) => {
        const regex = /^[A-Z]{1,2}[0-9][A-Z0-9]? ?[0-9][A-Z]{2}$/i;
        return regex.test(postcode);
    }
};

// Date formatting utilities
const DateUtils = {
    format: (date, format = 'short') => {
        const d = new Date(date);
        return d.toLocaleDateString('en-GB', {
            year: 'numeric',
            month: format === 'short' ? 'short' : 'long',
            day: 'numeric'
        });
    },

    relative: (date) => {
        const now = new Date();
        const diffTime = Math.abs(now - new Date(date));
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) return 'Yesterday';
        if (diffDays < 7) return `${diffDays} days ago`;
        if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
        if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
        return `${Math.floor(diffDays / 365)} years ago`;
    }
};

// DOM utilities
const DOM = {
    ready: (fn) => {
        if (document.readyState !== 'loading') {
            fn();
        } else {
            document.addEventListener('DOMContentLoaded', fn);
        }
    },

    create: (tag, attributes = {}, children = []) => {
        const element = document.createElement(tag);
        
        Object.entries(attributes).forEach(([key, value]) => {
            if (key === 'className') {
                element.className = value;
            } else if (key === 'textContent') {
                element.textContent = value;
            } else if (key === 'innerHTML') {
                element.innerHTML = value;
            } else {
                element.setAttribute(key, value);
            }
        });

        children.forEach(child => {
            if (typeof child === 'string') {
                element.appendChild(document.createTextNode(child));
            } else {
                element.appendChild(child);
            }
        });

        return element;
    },

    show: (element) => {
        element.style.display = '';
    },

    hide: (element) => {
        element.style.display = 'none';
    },

    toggle: (element, force) => {
        if (force !== undefined) {
            element.style.display = force ? '' : 'none';
        } else {
            element.style.display = element.style.display === 'none' ? '' : 'none';
        }
    }
};

// Analytics utilities (for tracking user interactions)
const Analytics = {
    track: (event, data = {}) => {
        // In a real app, this would send data to your analytics service
        console.log('Analytics Event:', event, data);
        
        // Store events in localStorage for demo purposes
        const events = Storage.get('analytics-events') || [];
        events.push({
            event,
            data,
            timestamp: new Date().toISOString()
        });
        Storage.set('analytics-events', events);
    },

    pageView: (page) => {
        Analytics.track('page_view', { page });
    },

    productView: (productId, productName) => {
        Analytics.track('product_view', { productId, productName });
    },

    addToCart: (productId, productName, price) => {
        Analytics.track('add_to_cart', { productId, productName, price });
    },

    purchase: (orderId, total, items) => {
        Analytics.track('purchase', { orderId, total, items });
    }
};

// Performance monitoring
const Performance = {
    startTime: null,
    
    start: () => {
        Performance.startTime = performance.now();
    },
    
    end: (label) => {
        if (Performance.startTime) {
            const duration = performance.now() - Performance.startTime;
            console.log(`${label}: ${duration.toFixed(2)}ms`);
            Performance.startTime = null;
        }
    },
    
    measure: async (label, fn) => {
        Performance.start();
        const result = await fn();
        Performance.end(label);
        return result;
    }
};

// Error handling utilities
const ErrorHandler = {
    capture: (error, context = {}) => {
        console.error('Error captured:', error, context);
        
        // In a real app, this would send to error tracking service
        const errors = Storage.get('error-logs') || [];
        errors.push({
            error: error.message,
            stack: error.stack,
            context,
            timestamp: new Date().toISOString(),
            url: window.location.href,
            userAgent: navigator.userAgent
        });
        Storage.set('error-logs', errors);
        
        // Show user-friendly error message
        showNotification('Something went wrong. Please try again.', 'error');
    },
    
    wrap: (fn, context = {}) => {
        return async (...args) => {
            try {
                return await fn(...args);
            } catch (error) {
                ErrorHandler.capture(error, context);
                throw error;
            }
        };
    }
};

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        formatPrice,
        debounce,
        throttle,
        Storage,
        Validators,
        DateUtils,
        DOM,
        Analytics,
        Performance,
        ErrorHandler
    };
}