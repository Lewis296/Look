// Main JavaScript functionality for SHUU website

// Theme Toggle Functionality
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = themeToggle?.querySelector('i');

function initializeTheme() {
    const savedTheme = localStorage.getItem('shuu-theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    if (themeIcon) {
        themeIcon.className = savedTheme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
    }
    
    // Update any theme-specific elements
    updateThemeDependentElements(savedTheme);
}

function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('shuu-theme', newTheme);
    
    if (themeIcon) {
        themeIcon.className = newTheme === 'dark' ? 'fas fa-moon' : 'fas fa-sun';
    }
    
    updateThemeDependentElements(newTheme);
}

function updateThemeDependentElements(theme) {
    // Update any elements that need theme-specific adjustments
    const brandLogos = document.querySelectorAll('.brand-logo img');
    brandLogos.forEach(logo => {
        if (theme === 'dark') {
            logo.style.filter = 'brightness(0) invert(1)';
        } else {
            logo.style.filter = 'brightness(0)';
        }
    });
}

// Mobile Menu Functionality
const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
const navLinks = document.querySelector('.nav-links');

function toggleMobileMenu() {
    navLinks.classList.toggle('active');
    
    // Toggle menu icon
    const menuIcon = mobileMenuBtn.querySelector('i');
    if (navLinks.classList.contains('active')) {
        menuIcon.className = 'fas fa-times';
    } else {
        menuIcon.className = 'fas fa-bars';
    }
}

function closeMobileMenu() {
    navLinks.classList.remove('active');
    const menuIcon = mobileMenuBtn.querySelector('i');
    menuIcon.className = 'fas fa-bars';
}

// Cart Functionality
const cartIcon = document.getElementById('cart-icon');
const cartSidebar = document.getElementById('cart-sidebar');
const closeCart = document.getElementById('close-cart');
const overlay = document.getElementById('overlay');

function openCart() {
    cartSidebar.classList.add('active');
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeCartSidebar() {
    cartSidebar.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
}

// Product Card Animations
function initializeProductAnimations() {
    const productCards = document.querySelectorAll('.product-card');
    
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries, observer) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    productCards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
        observer.observe(card);
    });
}

// Add to Cart Functionality
function initializeAddToCart() {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const productCard = this.closest('.product-card');
            const productName = productCard.querySelector('.product-title').textContent;
            const productPrice = productCard.querySelector('.current-price').textContent;
            const productImage = productCard.querySelector('.product-image img').src;
            
            // Show added notification
            const originalText = this.textContent;
            this.textContent = 'ADDED!';
            this.style.background = 'var(--accent)';
            
            setTimeout(() => {
                this.textContent = originalText;
                this.style.background = '';
            }, 2000);
            
            // Add to cart logic
            addToCart({
                name: productName,
                price: productPrice,
                image: productImage,
                quantity: 1
            });
            
            // Update cart count
            updateCartCount();
        });
    });
}

function addToCart(product) {
    let cart = JSON.parse(localStorage.getItem('shuu-cart')) || [];
    
    // Check if product already exists in cart
    const existingProductIndex = cart.findIndex(item => item.name === product.name);
    
    if (existingProductIndex > -1) {
        cart[existingProductIndex].quantity += 1;
    } else {
        cart.push(product);
    }
    
    localStorage.setItem('shuu-cart', JSON.stringify(cart));
    
    // Show notification
    showNotification(`${product.name} added to cart!`);
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('shuu-cart')) || [];
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
    
    const cartCount = document.querySelector('.cart-count');
    if (cartCount) {
        if (totalItems > 0) {
            cartCount.textContent = totalItems;
            cartCount.style.display = 'flex';
        } else {
            cartCount.style.display = 'none';
        }
    }
}

// Notification System
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check' : 'exclamation'}"></i>
            <span>${message}</span>
        </div>
    `;
    
    // Add styles if not already added
    if (!document.querySelector('#notification-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 100px;
                right: 20px;
                background: var(--glass-bg);
                backdrop-filter: var(--blur);
                border: 1px solid var(--glass-border);
                border-radius: 10px;
                padding: 15px 20px;
                color: var(--text-primary);
                box-shadow: var(--glass-shadow);
                z-index: 10000;
                transform: translateX(400px);
                transition: transform 0.3s ease;
                max-width: 300px;
            }
            .notification.show {
                transform: translateX(0);
            }
            .notification-success {
                border-left: 4px solid var(--success);
            }
            .notification-error {
                border-left: 4px solid var(--error);
            }
            .notification-content {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .notification-content i {
                font-size: 1.2rem;
            }
            .notification-success .notification-content i {
                color: var(--success);
            }
            .notification-error .notification-content i {
                color: var(--error);
            }
        `;
        document.head.appendChild(styles);
    }
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => notification.classList.add('show'), 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Newsletter Form
function initializeNewsletter() {
    const newsletterForm = document.querySelector('.newsletter-form');
    
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            
            // Simulate API call
            setTimeout(() => {
                showNotification('Thanks for subscribing! You\'ll hear from us soon.', 'success');
                this.reset();
            }, 1000);
        });
    }
}

// Account Navigation
function initializeAccountNavigation() {
    const accountNavLinks = document.querySelectorAll('.account-nav-link');
    const accountSections = document.querySelectorAll('.account-section');
    
    accountNavLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href').substring(1);
            
            // Update active states
            accountNavLinks.forEach(navLink => navLink.classList.remove('active'));
            this.classList.add('active');
            
            // Show target section
            accountSections.forEach(section => {
                section.classList.remove('active');
                if (section.id === targetId) {
                    section.classList.add('active');
                }
            });
        });
    });
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize theme
    initializeTheme();
    
    // Initialize mobile menu
    if (mobileMenuBtn && navLinks) {
        mobileMenuBtn.addEventListener('click', toggleMobileMenu);
        
        // Close mobile menu when clicking on links
        const navItems = document.querySelectorAll('.nav-links a');
        navItems.forEach(item => {
            item.addEventListener('click', closeMobileMenu);
        });
    }
    
    // Initialize cart functionality
    if (cartIcon) {
        cartIcon.addEventListener('click', function(e) {
            e.preventDefault();
            openCart();
        });
    }
    
    if (closeCart) {
        closeCart.addEventListener('click', closeCartSidebar);
    }
    
    if (overlay) {
        overlay.addEventListener('click', closeCartSidebar);
    }
    
    // Initialize theme toggle
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
    
    // Initialize product animations
    initializeProductAnimations();
    
    // Initialize add to cart buttons
    initializeAddToCart();
    
    // Initialize newsletter
    initializeNewsletter();
    
    // Initialize account navigation
    initializeAccountNavigation();
    
    // Update cart count on page load
    updateCartCount();
    
    // Add loading animation to images
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.addEventListener('load', function() {
            this.style.opacity = '1';
        });
        
        // Set initial opacity for fade-in effect
        img.style.opacity = '0';
        img.style.transition = 'opacity 0.3s ease';
        
        // If image is already loaded (cached)
        if (img.complete) {
            img.style.opacity = '1';
        }
    });
});

// Utility function for formatting prices
function formatPrice(price) {
    return new Intl.NumberFormat('en-GB', {
        style: 'currency',
        currency: 'GBP'
    }).format(price);
}

// Utility function for debouncing
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Export functions for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initializeTheme,
        toggleTheme,
        addToCart,
        updateCartCount,
        formatPrice,
        debounce
    };
}
// Loading Screen Functionality
document.addEventListener('DOMContentLoaded', function() {
    const loadingScreen = document.getElementById('loading-screen');
    const mainContent = document.getElementById('main-content');
    const categoryBoxes = document.querySelectorAll('.category-box');
    const viewAllBtn = document.querySelector('.view-all-btn');

    // Check if user has already selected a category (using sessionStorage)
    const hasSelectedCategory = sessionStorage.getItem('categorySelected');

    if (hasSelectedCategory) {
        // If category already selected, hide loading screen immediately
        hideLoadingScreen();
    } else {
        // Show loading screen for first-time visitors
        setTimeout(() => {
            loadingScreen.classList.add('active');
        }, 100);
    }

    // Category selection handler
    categoryBoxes.forEach(box => {
        box.addEventListener('click', function() {
            const category = this.getAttribute('data-category');
            selectCategory(category);
        });
    });

    // View all button handler
    viewAllBtn.addEventListener('click', function() {
        selectCategory('all');
    });

    function selectCategory(category) {
        // Add selection animation
        const selectedBox = document.querySelector(`[data-category="${category}"]`);
        if (selectedBox) {
            selectedBox.style.transform = 'scale(0.95)';
            selectedBox.style.background = 'rgba(255, 51, 102, 0.1)';
        }

        // Store selection in session storage
        sessionStorage.setItem('categorySelected', 'true');
        sessionStorage.setItem('lastCategory', category);

        // Hide loading screen after a short delay
        setTimeout(hideLoadingScreen, 500);
    }

    function hideLoadingScreen() {
        loadingScreen.classList.remove('active');
        loadingScreen.classList.add('hidden');
        
        // Show main content
        mainContent.classList.add('active');
        
        // Remove loading screen from DOM after transition
        setTimeout(() => {
            loadingScreen.style.display = 'none';
        }, 500);
    }

    // Optional: Keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (!loadingScreen.classList.contains('active')) return;

        switch(e.key) {
            case '1':
                selectCategory('men');
                break;
            case '2':
                selectCategory('women');
                break;
            case '3':
                selectCategory('kids');
                break;
            case 'Enter':
            case ' ':
                selectCategory('all');
                break;
        }
    });
});

// Your existing main.js code continues below...