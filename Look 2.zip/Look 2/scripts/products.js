// Products page functionality for SHUU website

class ProductFilter {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.currentFilters = {
            brand: [],
            size: [],
            priceRange: { min: 0, max