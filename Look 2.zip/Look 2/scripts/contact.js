// Contact page functionality for SHUU website

class ContactForm {
    constructor() {
        this.form = document.getElementById('contactForm');
        this.init();
    }

    init() {
        if (this.form) {
            this.attachEventListeners();
            this.initializeFormValidation();
        }
    }

    attachEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        
        // Real-time validation
        const inputs = this.form.querySelectorAll('input, textarea, select');
        inputs.forEach(input => {
            input.addEventListener('blur', () => this.validateField(input));
            input.addEventListener('input', () => this.clearFieldError(input));
        });
    }

    initializeFormValidation() {
        // Add custom validation methods
        this.addCustomValidation();
    }

    addCustomValidation() {
        // Phone number validation
        const phoneInput = this.form.querySelector('input[type="tel"]');
        if (phoneInput) {
            phoneInput.addEventListener('input', (e) => {
                e.target.value = e.target.value.replace(/[^0-9+-\s]/g, '');
            });
        }

        // Email validation
        const emailInput = this.form.querySelector('input[type="email"]');
        if (emailInput) {
            emailInput.addEventListener('blur', (e) => {
                if (e.target.value && !this.isValidEmail(e.target.value)) {
                    this.showFieldError(e.target, 'Please enter a valid email address');
                }
            });
        }
    }

    handleSubmit(e) {
        e.preventDefault();
        
        if (this.validateForm()) {
            this.submitForm();
        }
    }

    validateForm() {
        let isValid = true;
        const fields = this.form.querySelectorAll('input, textarea, select');
        
        fields.forEach(field => {
            if (!this.validateField(field)) {
                isValid = false;
            }
        });

        return isValid;
    }

    validateField(field) {
        const value = field.value.trim();
        const isRequired = field.hasAttribute('required');
        
        // Clear previous errors
        this.clearFieldError(field);

        // Check required fields
        if (isRequired && !value) {
            this.showFieldError(field, 'This field is required');
            return false;
        }

        // Email validation
        if (field.type === 'email' && value && !this.isValidEmail(value)) {
            this.showFieldError(field, 'Please enter a valid email address');
            return false;
        }

        // Phone validation
        if (field.type === 'tel' && value && !this.isValidPhone(value)) {
            this.showFieldError(field, 'Please enter a valid phone number');
            return false;
        }

        // Message length validation
        if (field.name === 'message' && value.length < 10) {
            this.showFieldError(field, 'Please enter at least 10 characters');
            return false;
        }

        return true;
    }

    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    isValidPhone(phone) {
        const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
        return phoneRegex.test(phone.replace(/\s/g, ''));
    }

    showFieldError(field, message) {
        // Remove existing error
        this.clearFieldError(field);

        // Add error class
        field.classList.add('error');

        // Create error message
        const errorElement = document.createElement('div');
        errorElement.className = 'field-error';
        errorElement.textContent = message;
        errorElement.style.cssText = `
            color: var(--error);
            font-size: 0.8rem;
            margin-top: 5px;
            display: flex;
            align-items: center;
            gap: 5px;
        `;

        // Insert after field
        field.parentNode.insertBefore(errorElement, field.nextSibling);
    }

    clearFieldError(field) {
        field.classList.remove('error');
        const existingError = field.parentNode.querySelector('.field-error');
        if (existingError) {
            existingError.remove();
        }
    }

    async submitForm() {
        const formData = new FormData(this.form);
        const submitButton = this.form.querySelector('button[type="submit"]');
        const originalText = submitButton.textContent;

        try {
            // Show loading state
            submitButton.textContent = 'SENDING...';
            submitButton.disabled = true;

            // Simulate API call
            await this.simulateAPICall(formData);

            // Show success message
            showNotification('Message sent successfully! We\'ll get back to you soon.', 'success');
            
            // Reset form
            this.form.reset();
            
            // Track contact form submission
            this.trackContactSubmission(formData);

        } catch (error) {
            showNotification('Failed to send message. Please try again.', 'error');
            console.error('Contact form error:', error);
        } finally {
            // Reset button state
            submitButton.textContent = originalText;
            submitButton.disabled = false;
        }
    }

    simulateAPICall(formData) {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Simulate random success/failure for demo
                if (Math.random() > 0.1) { // 90% success rate
                    resolve({ success: true });
                } else {
                    reject(new Error('Network error'));
                }
            }, 2000);
        });
    }

    trackContactSubmission(formData) {
        const contactData = {
            timestamp: new Date().toISOString(),
            subject: formData.get('subject'),
            category: 'contact_form'
        };

        // Store in localStorage for demo purposes
        const submissions = JSON.parse(localStorage.getItem('shuu-contact-submissions')) || [];
        submissions.push(contactData);
        localStorage.setItem('shuu-contact-submissions', JSON.stringify(submissions));

        // Log to console for demo
        console.log('Contact form submitted:', contactData);
    }
}

// FAQ functionality
class FAQManager {
    constructor() {
        this.faqItems = document.querySelectorAll('.faq-item');
        this.init();
    }

    init() {
        if (this.faqItems.length > 0) {
            this.attachEventListeners();
        }
    }

    attachEventListeners() {
        this.faqItems.forEach(item => {
            item.addEventListener('click', () => this.toggleFAQ(item));
        });
    }

    toggleFAQ(item) {
        const isExpanded = item.classList.contains('expanded');
        
        // Close all other FAQs
        this.faqItems.forEach(faq => {
            if (faq !== item) {
                faq.classList.remove('expanded');
                this.hideAnswer(faq);
            }
        });

        // Toggle current FAQ
        if (!isExpanded) {
            item.classList.add('expanded');
            this.showAnswer(item);
        } else {
            item.classList.remove('expanded');
            this.hideAnswer(item);
        }
    }

    showAnswer(item) {
        let answer = item.querySelector('.faq-answer');
        if (!answer) {
            // Create answer element if it doesn't exist
            const question = item.querySelector('h3').textContent;
            const answerText = this.getAnswerText(question);
            
            answer = document.createElement('div');
            answer.className = 'faq-answer';
            answer.innerHTML = `<p>${answerText}</p>`;
            answer.style.cssText = `
                margin-top: 15px;
                padding-top: 15px;
                border-top: 1px solid var(--glass-border);
                color: var(--text-secondary);
                line-height: 1.6;
            `;
            
            item.appendChild(answer);
        }
        
        answer.style.display = 'block';
        item.style.paddingBottom = '25px';
    }

    hideAnswer(item) {
        const answer = item.querySelector('.faq-answer');
        if (answer) {
            answer.style.display = 'none';
        }
        item.style.paddingBottom = '';
    }

    getAnswerText(question) {
        // Mock answers for demo - in a real app, these would come from a database
        const answers = {
            'How long does shipping take?': 'Standard shipping takes 3-5 business days within the UK. Express shipping is available for next-day delivery at an additional cost. International shipping times vary by location.',
            'What\'s your return policy?': 'We offer 30-day returns on all unworn items in original packaging. Return shipping is free for UK customers. International returns are subject to shipping costs.',
            'Do you ship internationally?': 'Yes! We ship worldwide to most countries. International shipping costs and delivery times vary based on your location. You can see the exact costs at checkout.',
            'How do I track my order?': 'You\'ll receive a tracking number via email once your order ships. You can also track your order by logging into your account and visiting the "My Orders" section.',
            'What payment methods do you accept?': 'We accept all major credit cards (Visa, MasterCard, American Express), PayPal, Apple Pay, and Google Pay. All payments are secure and encrypted.',
            'How do I change my order?': 'If you need to change your order, please contact us immediately at hello@shuu.com with your order number. We can only modify orders that haven\'t been shipped yet.',
            'Do you offer student discount?': 'Yes! We offer a 10% student discount for verified students. Sign up with your student email or verify through UNiDAYS to receive your discount code.',
            'Are the products authentic?': 'Absolutely! We guarantee 100% authenticity for all our products. Every item is verified by our expert team before shipping. No fakes, no compromises.'
        };

        return answers[question] || 'Please contact our support team for more information about this topic.';
    }
}

// Store locator functionality (simplified for demo)
class StoreLocator {
    constructor() {
        this.stores = [
            {
                id: 1,
                name: 'SHUU London Flagship',
                address: '123 Sneaker Street, London, W1S 1AB',
                phone: '+44 20 7123 4567',
                hours: {
                    weekdays: '10:00 - 20:00',
                    saturday: '10:00 - 19:00',
                    sunday: '11:00 - 17:00'
                },
                coordinates: { lat: 51.5074, lng: -0.1278 }
            },
            {
                id: 2,
                name: 'SHUU Manchester',
                address: '456 Trainer Road, Manchester, M1 1AB',
                phone: '+44 161 123 4567',
                hours: {
                    weekdays: '10:00 - 19:00',
                    saturday: '10:00 - 18:00',
                    sunday: '11:00 - 16:00'
                },
                coordinates: { lat: 53.4808, lng: -2.2426 }
            }
        ];
        
        this.init();
    }

    init() {
        this.renderStores();
        this.attachEventListeners();
    }

    renderStores() {
        const storeContainer = document.querySelector('.store-locator');
        if (!storeContainer) return;

        storeContainer.innerHTML = this.stores.map(store => `
            <div class="store-card" data-store-id="${store.id}">
                <div class="store-header">
                    <h3>${store.name}</h3>
                    <span class="store-distance">~${Math.floor(Math.random() * 5) + 1} miles away</span>
                </div>
                <div class="store-info">
                    <p><i class="fas fa-map-marker-alt"></i> ${store.address}</p>
                    <p><i class="fas fa-phone"></i> ${store.phone}</p>
                    <div class="store-hours">
                        <h4>Opening Hours:</h4>
                        <p>Mon-Fri: ${store.hours.weekdays}</p>
                        <p>Saturday: ${store.hours.saturday}</p>
                        <p>Sunday: ${store.hours.sunday}</p>
                    </div>
                </div>
                <div class="store-actions">
                    <button class="btn btn-outline" onclick="storeLocator.getDirections(${store.id})">
                        <i class="fas fa-directions"></i> Get Directions
                    </button>
                    <button class="btn-text" onclick="storeLocator.callStore(${store.id})">
                        <i class="fas fa-phone"></i> Call Store
                    </button>
                </div>
            </div>
        `).join('');
    }

    attachEventListeners() {
        // Store search functionality
        const storeSearch = document.querySelector('.store-search');
        if (storeSearch) {
            storeSearch.addEventListener('input', debounce((e) => {
                this.searchStores(e.target.value);
            }, 300));
        }
    }

    searchStores(query) {
        const filteredStores = this.stores.filter(store =>
            store.name.toLowerCase().includes(query.toLowerCase()) ||
            store.address.toLowerCase().includes(query.toLowerCase())
        );

        this.renderFilteredStores(filteredStores);
    }

    renderFilteredStores(stores) {
        const storeContainer = document.querySelector('.store-locator');
        if (!storeContainer) return;

        if (stores.length === 0) {
            storeContainer.innerHTML = `
                <div class="no-stores">
                    <i class="fas fa-store-slash"></i>
                    <h3>No stores found</h3>
                    <p>Try searching for a different location</p>
                </div>
            `;
            return;
        }

        this.renderStores();
    }

    getDirections(storeId) {
        const store = this.stores.find(s => s.id === storeId);
        if (store) {
            // For demo purposes, open Google Maps with coordinates
            const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${store.coordinates.lat},${store.coordinates.lng}`;
            window.open(mapsUrl, '_blank');
            
            showNotification(`Opening directions to ${store.name}`, 'success');
        }
    }

    callStore(storeId) {
        const store = this.stores.find(s => s.id === storeId);
        if (store) {
            // For demo purposes, show a confirmation
            if (confirm(`Call ${store.name} at ${store.phone}?`)) {
                window.location.href = `tel:${store.phone}`;
            }
        }
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize contact form
    if (document.getElementById('contactForm')) {
        window.contactForm = new ContactForm();
    }

    // Initialize FAQ manager
    if (document.querySelector('.faq-grid')) {
        window.faqManager = new FAQManager();
    }

    // Initialize store locator
    if (document.querySelector('.store-locator')) {
        window.storeLocator = new StoreLocator();
    }

    // Add contact page specific styles
    if (!document.querySelector('#contact-styles')) {
        const styles = document.createElement('style');
        styles.id = 'contact-styles';
        styles.textContent = `
            .field-error {
                color: var(--error);
                font-size: 0.8rem;
                margin-top: 5px;
                display: flex;
                align-items: center;
                gap: 5px;
            }
            .form-control.error {
                border-color: var(--error);
                box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.1);
            }
            .faq-item {
                cursor: pointer;
                transition: all 0.3s ease;
            }
            .faq-item.expanded {
                background: rgba(255, 255, 255, 0.05);
                border-color: var(--accent);
            }
            .faq-item h3 {
                position: relative;
                padding-right: 30px;
            }
            .faq-item h3::after {
                content: '+';
                position: absolute;
                right: 0;
                top: 50%;
                transform: translateY(-50%);
                font-size: 1.2rem;
                font-weight: 300;
                transition: transform 0.3s ease;
            }
            .faq-item.expanded h3::after {
                content: '−';
                transform: translateY(-50%) rotate(0deg);
            }
            .store-locator {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 20px;
                margin-top: 30px;
            }
            .store-card {
                background: var(--glass-bg);
                backdrop-filter: var(--blur);
                border: 1px solid var(--glass-border);
                border-radius: 15px;
                padding: 25px;
                transition: all 0.3s ease;
            }
            .store-card:hover {
                border-color: var(--accent);
                transform: translateY(-2px);
            }
            .store-header {
                display: flex;
                justify-content: space-between;
                align-items: flex-start;
                margin-bottom: 15px;
            }
            .store-header h3 {
                margin-bottom: 5px;
                color: var(--text-primary);
            }
            .store-distance {
                color: var(--accent);
                font-size: 0.9rem;
                font-weight: 600;
            }
            .store-info p {
                display: flex;
                align-items: center;
                gap: 10px;
                margin-bottom: 10px;
                color: var(--text-secondary);
            }
            .store-info i {
                color: var(--accent);
                width: 16px;
            }
            .store-hours {
                margin-top: 15px;
                padding-top: 15px;
                border-top: 1px solid var(--glass-border);
            }
            .store-hours h4 {
                margin-bottom: 8px;
                color: var(--text-primary);
                font-size: 0.9rem;
            }
            .store-hours p {
                font-size: 0.8rem;
                margin-bottom: 5px;
            }
            .store-actions {
                display: flex;
                gap: 10px;
                margin-top: 20px;
            }
            .store-actions .btn {
                flex: 1;
            }
            .store-actions .btn-text {
                flex-shrink: 0;
            }
            .no-stores {
                text-align: center;
                padding: 40px 20px;
                color: var(--text-secondary);
                grid-column: 1 / -1;
            }
            .no-stores i {
                font-size: 2rem;
                margin-bottom: 15px;
                opacity: 0.5;
            }
            .store-search {
                width: 100%;
                max-width: 400px;
                margin-bottom: 30px;
            }
            @media (max-width: 768px) {
                .store-actions {
                    flex-direction: column;
                }
            }
        `;
        document.head.appendChild(styles);
    }
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        ContactForm,
        FAQManager,
        StoreLocator
    };
}