// Service Worker for SHUU website
const CACHE_NAME = 'shuu-v1.0.0';
const STATIC_CACHE = 'shuu-static-v1.0.0';
const DYNAMIC_CACHE = 'shuu-dynamic-v1.0.0';

// Assets to cache immediately
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/styles/main.css',
    '/styles/components.css',
    '/styles/dark-mode.css',
    '/styles/animations.css',
    '/styles/responsive.css',
    '/scripts/main.js',
    '/scripts/utils.js',
    '/scripts/cart.js',
    '/scripts/auth.js',
    '/scripts/products.js',
    '/scripts/contact.js',
    '/manifest.json',
    'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'
];

// Install event - cache static assets
self.addEventListener('install', (event) => {
    console.log('Service Worker installing...');
    event.waitUntil(
        caches.open(STATIC_CACHE)
            .then(cache => {
                console.log('Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
            .then(() => self.skipWaiting())
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
    console.log('Service Worker activating...');
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== STATIC_CACHE && cacheName !== DYNAMIC_CACHE) {
                        console.log('Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(() => self.clients.claim())
    );
});

// Fetch event - serve from cache or network
self.addEventListener('fetch', (event) => {
    // Skip non-GET requests
    if (event.request.method !== 'GET') return;

    // Skip Chrome extensions
    if (event.request.url.startsWith('chrome-extension://')) return;

    event.respondWith(
        caches.match(event.request)
            .then(cachedResponse => {
                // Return cached version if available
                if (cachedResponse) {
                    return cachedResponse;
                }

                // Otherwise fetch from network
                return fetch(event.request)
                    .then(networkResponse => {
                        // Check if we received a valid response
                        if (!networkResponse || networkResponse.status !== 200 || networkResponse.type !== 'basic') {
                            return networkResponse;
                        }

                        // Clone the response
                        const responseToCache = networkResponse.clone();

                        // Add to dynamic cache
                        caches.open(DYNAMIC_CACHE)
                            .then(cache => {
                                cache.put(event.request, responseToCache);
                            });

                        return networkResponse;
                    })
                    .catch(error => {
                        // Fallback for failed requests
                        console.log('Fetch failed; returning offline page:', error);
                        
                        // If it's a document request, return offline page
                        if (event.request.destination === 'document') {
                            return caches.match('/index.html');
                        }
                        
                        // For images, return a placeholder
                        if (event.request.destination === 'image') {
                            return caches.match('/assets/images/placeholder.jpg');
                        }
                    });
            })
    );
});

// Background sync for form submissions
self.addEventListener('sync', (event) => {
    if (event.tag === 'background-sync') {
        console.log('Background sync triggered');
        event.waitUntil(doBackgroundSync());
    }
});

async function doBackgroundSync() {
    // Sync pending form submissions, cart updates, etc.
    const pendingSubmissions = await getPendingSubmissions();
    
    for (const submission of pendingSubmissions) {
        try {
            await submitFormData(submission);
            await removePendingSubmission(submission.id);
        } catch (error) {
            console.error('Background sync failed:', error);
        }
    }
}

// Helper functions for background sync
async function getPendingSubmissions() {
    // Get pending submissions from IndexedDB or localStorage
    return JSON.parse(localStorage.getItem('shuu-pending-submissions') || '[]');
}

async function submitFormData(submission) {
    // Simulate form submission
    return new Promise((resolve) => {
        setTimeout(resolve, 1000);
    });
}

async function removePendingSubmission(id) {
    const submissions = JSON.parse(localStorage.getItem('shuu-pending-submissions') || '[]');
    const updatedSubmissions = submissions.filter(s => s.id !== id);
    localStorage.setItem('shuu-pending-submissions', JSON.stringify(updatedSubmissions));
}

// Push notifications
self.addEventListener('push', (event) => {
    if (!event.data) return;

    const data = event.data.json();
    const options = {
        body: data.body,
        icon: '/assets/icons/icon-192x192.png',
        badge: '/assets/icons/badge-72x72.png',
        vibrate: [100, 50, 100],
        data: {
            url: data.url || '/'
        },
        actions: [
            {
                action: 'view',
                title: 'View'
            },
            {
                action: 'dismiss',
                title: 'Dismiss'
            }
        ]
    };

    event.waitUntil(
        self.registration.showNotification(data.title, options)
    );
});

self.addEventListener('notificationclick', (event) => {
    event.notification.close();

    if (event.action === 'view') {
        event.waitUntil(
            clients.openWindow(event.notification.data.url)
        );
    }
});